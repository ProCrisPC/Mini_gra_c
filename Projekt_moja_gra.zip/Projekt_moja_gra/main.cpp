#include <iostream>
#include <windows.h>
#include <cstdlib>
#include <time.h>
#include <stdio.h>
#include <conio.h>
using namespace std;
int losowe_przypatki, atak_gaben, leczenie;
int zycie_gaben=100, zycie_twoje=100, psychika=100;
string przedmiot[10];
char twoj_atak, koniec;
int main()
{
    srand(time(NULL));
    cout << "Otpalasz kompa i nagle przeceny steama" << endl<< "nie mozesz dopuscic do smierci swojego portfela" << endl;
    //getchar();
    do
    {
    do
    {
    //system losowania
    atak_gaben=rand()%3+1;
    losowe_przypatki=rand()%3+1;
    leczenie=rand()%41+40;
    /*to jest menu gracza*/
    do
    {
    cout << "twoj stan zdrowia:" << zycie_twoje << endl;
    cout << "twoj stan psychiczny:" << psychika << endl;
    cout << "wybierz swoja akcje:" << endl;
    cout << "1.To losowy atak" << endl;
    if (psychika>0)
    {
    	cout <<"2.Leczenie"<< endl;
	}
    cout <<"3.Wyjdz z gry"<< endl;
    twoj_atak = getch();
     /*twoje ataki*/
    switch (twoj_atak)
    {
    case '1':
    {
    if (losowe_przypatki==1)
    {
            zycie_gaben=zycie_gaben-20;
            cout << "Grasz darmowe lub posiadane gry nie wydajac ani grosza" << endl<< "zadajesz 20 hp gabenowi"<< endl;
    }
    else if (losowe_przypatki==2)
    {
            zycie_gaben=zycie_gaben-30;
            cout << "Dajesz krytyke popularnym produkcja co inny zniechenca do kupna ich" << endl << "zadajesz 30 hp gabenowi"<< endl;
    }
    else if (losowe_przypatki==3)
    {
            zycie_gaben=zycie_gaben-40;
            cout << "postaniawias grac w minecrafta caly dzien" << endl << "zadajesz 40 hp gabenowi" << endl;
    }
    }break;
    /*leczenie losowe*/

    case '2':
    {
    	if (psychika>0)
    	{
			zycie_twoje+=leczenie;
            cout << "oszczedzasz dzis swoja kase i nic nie wydajesz" << endl << "leczysz:"<< leczenie << "hp" << endl;
        }
        else //system zabespieczenia przed cwaniakami kiedy jest 0 psy
        {
        	twoj_atak=0;
        	cout << "nie badz cwany :)"<<endl;
			getchar();
        	system("cls");
		}
    }break;
    case '3':
    exit(0);
    break;

     default:
    {
        cout << "podales zla liczbe, sprobuj ponownie!"<<endl;
		getchar();
		system("cls");
    }
    }
    }while ((twoj_atak!='1')&&(twoj_atak!='2')); //zabezpieczenie przed cwaniakami lub pomylkami
    Sleep(1000);
    /*redukcja zdrowia do 100*/
    if (zycie_twoje>100)
        {
            zycie_twoje=100;
        }

    if ((zycie_gaben>0)&&(twoj_atak=='1'))
     {
         /*ataki Gabena*/
        if (atak_gaben==1)
        {
            zycie_twoje=zycie_twoje-20;
            cout<<"gaben daje ci atrakcyja skrzynke i wydajesz kase"<< endl<< "tracisz 20 hp"<< endl;
        }
        else if (atak_gaben==2)
        {
            zycie_twoje=zycie_twoje-40;
            cout << "gaben daje ci promoje na gry steam wydajesz kase na nie" << endl<< "tracisz 40 hp"<< endl;
        }
        else if (atak_gaben==3)
        {
            zycie_twoje=zycie_twoje-80;
            cout << "gaben przecenia perelki takie jak GTA 5 o %90 i wydajesz wszystko, twoj stan portfela jest ponizej zera"<< endl << "tracisz 80 hp"<< endl;
        }

     }
     //system atakow przychicznych
     if ((zycie_gaben>=0)&&(twoj_atak=='2'))
     {
     	if (atak_gaben==1)
     	{
     		psychika=psychika-20;
		 	cout<< "nic nowego nie pograles"<< endl << "tracisz 20 psy"<< endl;
		}
		else if (atak_gaben==2)
		{
			psychika=psychika-40;
			cout<< "nowe tytuly dostaja obizki cen, to cie stresuje"<<endl << "tracisz 40 psy"<< endl;
		}
		else if (atak_gaben==3)
		{
			psychika=psychika-80;
			zycie_twoje-80;
			cout<< "80% znirzki niszczy cie emocionalnie, zostajesz napromieniowany wierza 9G"<< endl<< "tracisz 80 psy i tracisz 20 hp" << endl;
		}

	 }
	 if (psychika<=0) //komunikat o psychice
	 {
	 	cout<< "twoj stan zdrowia jest krytyczny nie mozesz oszczedzac!!"<< endl;
	 }
    getchar();
    system("cls");
    }while ((zycie_gaben>0)&&(zycie_twoje>0));/*jezeli ktos nie zgina gra sie zapentla*/

    if (zycie_twoje<=0)
    {
        cout << "Wydalesz cala swoja kase,jak mogles!"<< endl<<"Bad ending"<<endl;
    }
    else
    {
        cout << "Przeceny juz minely a ty masz swoje oszczednosci."<<"\a"<< endl<<"Good ending"<<endl;
    }
    do
    {
    cout << endl;
    cout << "wykonal Krzysztof Sloderbach" << endl;
    cout << "grasz dalej? t/n"<< endl;
    koniec = getch();
    switch (koniec)
    {
        case't':
        {
        zycie_twoje=100;
        zycie_gaben=100;
        psychika=100;
        system("cls");
        }
        break;
        case'n':
		exit(0);
        break;
        default: cout<<"Podales zla litere" << endl;
    }
	}while (koniec!='t');
}while (true);
}

